from Simple_Genetic_Algorithm.genetic_algorithm import GA, get_random


